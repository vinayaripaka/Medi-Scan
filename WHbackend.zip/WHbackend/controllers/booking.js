const Booking = require('../models/booking.js')

const showBooking = (req, res) => {
    if(req.body.role == "user"){
        Booking.find({ from: req.body.id })
            .then((bookings) => {
                const data = {
                    status: 200,
                    description: "Done",
                    bookings: bookings
                }
                res.json(data)
            })
            .catch((err) => console.log(err))
    }
    else {
        Booking.find({to: req.body.id})
            .then((bookings) => {
                const data = {
                    status: 200,
                    description: "Done",
                    bookings: bookings
                }
                res.json(data)
            })
            .catch((err) => console.log(err))
    }
}

const createBooking = async(req, res) => {
    const newBooking = new Booking(req.body)
    await newBooking.save().then((response) => {
        const data = {
            status: 200,
            description: "created successfully"
        }
        res.json(data)
    }).catch((err) => console.log(err))
}



module.exports = {
    showBooking,
    createBooking
}
