const express = require('express')
const router = express.Router()
const { validateTestCenter, createTestCenter } = require('../controllers/testCenter.js')

router.post('/login', validateTestCenter)
router.post('/signup', createTestCenter)

module.exports = router 
