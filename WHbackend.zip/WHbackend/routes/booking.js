const express = require('express')
const router = express.Router()
const { showBooking, createBooking } = require('../controllers/booking.js')

router.post('/show', showBooking)
router.post('/create', createBooking)

module.exports = router
