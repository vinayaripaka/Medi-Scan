const express = require('express')
const router = express.Router()
const { showTest, createTest } = require('../controllers/test.js')

router.post('/show', showTest)
router.post('/create', createTest)

module.exports = router
